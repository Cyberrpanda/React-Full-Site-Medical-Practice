import "./index.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Navbar from "./Navbar";
import Slider from "./slider";
import Footer from "./footer";
import Services from "./Services";
import Speciality from "./Specialityareas";
import Status from "./Status";


export default function App() {
  return (
   
    <div>
      
      <div>
        <Navbar></Navbar>
      </div>

      <div>
        <Slider></Slider>
      </div>
      

      <div>
          <Services></Services>
      </div>
      
      <br />
      <br />

      <div>
          <Speciality></Speciality>
      </div>
      <br />
      <div>
        <Status></Status>
      </div>
      <br />
      <br />
      

      <br />
      <br />

      <div>
        <Footer></Footer>
      </div>
    </div>
  );
}


